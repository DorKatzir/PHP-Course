<?php 

class Response
{
    const NOT_FOUND = 400;
    const FORBIDDEN = 403;
}
<?php 
require 'functions.php';
require 'Database.php';
require 'Response.php';
require 'router.php';



/* $id = ($_GET['id']);

$query = "SELECT * FROM posts WHERE id = ?";

$posts = $db->query($query, [$id])->fetch();

ddr($posts); */




